<?php

namespace App\Models\Warehouse;

use App\Laravue\Models\User;
use Illuminate\Database\Eloquent\Model;

class UserWarehouse extends Model
{

}
