<?php

namespace  App\Models\Stock;

use Illuminate\Database\Eloquent\Relations\Pivot;
//use Illuminate\Database\Eloquent\Model;
class ItemTax extends Pivot
{
    //

}
