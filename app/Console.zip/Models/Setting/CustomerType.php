<?php

namespace App\Models\Setting;

use Illuminate\Database\Eloquent\Model;

class CustomerType extends Model
{
    //
}
